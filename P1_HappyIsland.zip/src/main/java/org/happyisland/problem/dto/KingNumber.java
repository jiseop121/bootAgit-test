package org.happyisland.problem.dto;

public class KingNumber {

    private final int number;

    public KingNumber(int number) {
        this.number = number;
    }

    public int getNumber() {
        return number;
    }
}
