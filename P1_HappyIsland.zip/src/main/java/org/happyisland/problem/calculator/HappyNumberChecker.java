package org.happyisland.problem.calculator;

public interface HappyNumberChecker {

    boolean isHappy(int n);
}
